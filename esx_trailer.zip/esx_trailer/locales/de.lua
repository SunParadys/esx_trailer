Locales['de'] = {
	['911_message_alarm'] = '~b~PLZ 61~s~ Alarm wurde ausgelöst',
	['notif_zone_name'] = '~y~Trailer Diebstahl~s~',
	['911_emergency']	= '911 Alamiert'
}