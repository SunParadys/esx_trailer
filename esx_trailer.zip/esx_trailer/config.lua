Config              = {}
Config.Locale       = 'de'

