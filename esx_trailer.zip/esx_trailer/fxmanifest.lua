fx_version 'adamant'

game 'gta5'

description 'ESX Trailer'

Author 'Sunparadys RP / https://discord.com/invite/nAahAnH9tm'

version '1.0'

server_scripts {
	'@es_extended/locale.lua',
	'@mysql-async/lib/MySQL.lua',
	'locales/de.lua',
	'config.lua',
	'server/main.lua'
}

client_scripts {
	'@es_extended/locale.lua',
	'locales/de.lua',
	'config.lua',
	'client/main.lua'
}

