local Keys = {
  ["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57, 
  ["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177, 
  ["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
  ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
  ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
  ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70, 
  ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
  ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
  ["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
}

ESX = nil
local PlayerData = {}
local sleep = 0

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
		PlayerData = ESX.GetPlayerData()
	end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
  PlayerData.job = job
end)

function hintToDisplay(text)
	SetTextComponentFormat("STRING")
	AddTextComponentString(text)
	DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end

local blips = {
	{title="Trailer Mieten", colour=56, id=318, x = 871.97, y = -2429.42, z = 28.08}
}
	
Citizen.CreateThread(function()

	for _, info in pairs(blips) do
		info.blip = AddBlipForCoord(info.x, info.y, info.z)
		SetBlipSprite(info.blip, info.id)
		SetBlipDisplay(info.blip, 4)
		SetBlipScale(info.blip, 0.7)
		SetBlipColour(info.blip, info.colour)
		SetBlipAsShortRange(info.blip, true)
		BeginTextCommandSetBlipName("STRING")
		AddTextComponentString(info.title)
		EndTextCommandSetBlipName(info.blip)
	end
end)


local renttrailer = {
    {x = 871.97,y = -2429.42,z = 28.08}
}


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
		sleep = 1500
		
        for k in pairs(renttrailer) do
			local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
			local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, renttrailer[k].x, renttrailer[k].y, renttrailer[k].z)
			if dist <= 20 then
				DrawMarker(39, renttrailer[k].x, renttrailer[k].y, renttrailer[k].z, 0, 0, 0, 0, 0, 0, 0.901, 0.901, 0.9001, 171, 130, 255, 100, 0, 0, 0, 0)
			end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
		sleep = 1500
        Citizen.Wait(0)

        for k in pairs(renttrailer) do
		
            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, renttrailer[k].x, renttrailer[k].y, renttrailer[k].z)

            if dist <= 1.5 then
				hintToDisplay('Trailer ~b~mieten')
				
				if IsControlJustPressed(0, Keys['E']) then -- "E"
					if IsPedInAnyVehicle(GetPlayerPed(-1)) then
						ESX.ShowNotification("Steige zuerst aus dem ~r~Fahrzeug")
					else
						OpenTrailerMenu()
					end
				end			
            end
        end
    end
end)

Config.Zones = {

	ShopOutside = {
		Pos     = vector3(879.94, -2423.8, 28.08),
		Size    = {x = 1.5, y = 1.5, z = 1.0},
		Heading = 175.24,
		Type    = -1
	}

}

function OpenTrailerMenu()
    ESX.UI.Menu.CloseAll()

    ESX.UI.Menu.Open(
        'default', GetCurrentResourceName(), 'trailer_menu',
        {
            title    = 'Einen Trailer mieten',
            elements = {
				{label = 'Tanker ($250)', value = 'tanker'},
				{label = 'Trailer ($290)', value = 'trailers'},
				{label = 'Holz Trailer ($190)', value = 'trailerlogs'},
				{label = 'Phantom TV Trailer ($270)', value = 'tvtrailer'},
				{label = 'Phantom Stahl Trailer ($299)', value = 'trailers4'},
            }
        },
        function(data, menu)
            if data.current.value == 'tanker' then
				TriggerServerEvent('esx_trailer:hireTanker')
				ESX.Game.SpawnVehicle('tanker', Config.Zones.ShopOutside.Pos, Config.Zones.ShopOutside.Heading)
				
				menu.close()
            elseif data.current.value == 'trailers' then
				TriggerServerEvent('esx_trailer:hireTrailers')
				ESX.Game.SpawnVehicle('trailers', Config.Zones.ShopOutside.Pos, Config.Zones.ShopOutside.Heading)
				
				menu.close()
            elseif data.current.value == 'tvtrailer' then
				TriggerServerEvent('esx_trailer:hireTvtrailer')
				ESX.Game.SpawnVehicle('tvtrailer', Config.Zones.ShopOutside.Pos, Config.Zones.ShopOutside.Heading)
				
				menu.close()
            elseif data.current.value == 'trailerlogs' then
				TriggerServerEvent('esx_trailer:hireTrailerlogs')
				ESX.Game.SpawnVehicle('trailerlogs', Config.Zones.ShopOutside.Pos, Config.Zones.ShopOutside.Heading)
				
				menu.close()
            elseif data.current.value == 'trailers4' then
				TriggerServerEvent('esx_trailer:hireTrailers4')
				ESX.Game.SpawnVehicle('trailers4', Config.Zones.ShopOutside.Pos, Config.Zones.ShopOutside.Heading)
				
				menu.close()
            end
        end,
        function(data, menu)
            menu.close()
        end
    )
end

RegisterNetEvent("esx_trailer:notification")
AddEventHandler("esx_trailer:notification", function(text)
    ESX.ShowHelpNotification(text)
end)

RegisterNetEvent("esx_trailer:notify")
AddEventHandler("esx_trailer:notify", function(text)
    ESX.ShowAdvancedNotification(_U('911_emergency'), _U('notif_zone_name'), _U('911_message_alarm'), 'CHAR_MP_MERRYWEATHER', 1)
    PlaySoundFrontend(-1, "HACKING_SUCCESS", 0, 1)
end)