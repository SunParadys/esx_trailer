ESX = nil

TriggerEvent('esx:getSharedObject', function(obj)
	ESX = obj
end)

RegisterServerEvent('esx_trailer:hireTanker')
AddEventHandler('esx_trailer:hireTanker', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	
	if xPlayer.getAccount('bank').money >= 250 then
		xPlayer.removeAccountMoney('bank', 250)
			
		notification("~b~Tanker~s~ gemietet. ~g~Betrag abgebucht")
	else
		notification("Willst du den Tanker ~r~stehlen?~s~ Hast nicht genug Geld auf dem Konto!")
		notification("~b~Polizei wurde Informiert")
		LSPD()
	end	
end)

RegisterServerEvent('esx_trailer:hireTrailers')
AddEventHandler('esx_trailer:hireTrailers', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	
	if xPlayer.getAccount('bank').money >= 290 then
		xPlayer.removeAccountMoney('bank', 290)
			
		notification("~b~Trailer~s~ gemietet. ~g~Betrag abgebucht")
	else
		notification("Willst du den Trailer ~r~stehlen?~s~ Hast nicht genug Geld auf dem Konto!")
		notification("~b~Polizei wurde Informiert")
		LSPD()
	end	
end)

RegisterServerEvent('esx_trailer:hireTvtrailer')
AddEventHandler('esx_trailer:hireTvtrailer', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	
	if xPlayer.getAccount('bank').money >= 270 then
		xPlayer.removeAccountMoney('bank', 270)
			
		notification("~b~TV Trailer~s~ gemietet. ~g~Betrag abgebucht")
	else
		notification("Willst du den TV Trailer ~r~stehlen?~s~ Hast nicht genug Geld auf dem Konto!")
		notification("~b~Polizei wurde Informiert")
		LSPD()
	end	
end)

RegisterServerEvent('esx_trailer:hireTrailerlogs')
AddEventHandler('esx_trailer:hireTrailerlogs', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	
	if xPlayer.getAccount('bank').money >= 190 then
		xPlayer.removeAccountMoney('bank', 190)
			
		notification("~b~Holz Trailer~s~ gemietet. ~g~Betrag abgebucht")
	else
		notification("Willst du den Holz Trailer ~r~stehlen?~s~ Hast nicht genug Geld auf dem Konto!")
		notification("~b~Polizei wurde Informiert")
		LSPD()
	end	
end)

RegisterServerEvent('esx_trailer:hireTrailers4')
AddEventHandler('esx_trailer:hireTrailers4', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	
	if xPlayer.getAccount('bank').money >= 299 then
		xPlayer.removeAccountMoney('bank', 299)
			
		notification("~b~Stahl Trailer~s~ gemietet. ~g~Betrag abgebucht")
	else
		notification("Willst du den Stahl Trailer ~r~stehlen?~s~ Hast nicht genug Geld auf dem Konto!")
		notification("~b~Polizei wurde Informiert")
		LSPD()
	end	
end)


function notification(text)
	TriggerClientEvent('esx:showNotification', source, text)
end


function LSPD()
	local _source = source
	local xPlayers = ESX.GetPlayers()

	for i=1, #xPlayers, 1 do
		xPlayer = ESX.GetPlayerFromId(xPlayers[i])

		if xPlayer.job.name == 'police' then
			TriggerClientEvent("esx_trailer:notify", -1)
		end
	end
end